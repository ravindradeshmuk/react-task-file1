import React from 'react'
import Card from './Componants/Card';

const App = () => {
  return (
    <>
    
    <Card name ="ravi">Welcome to Maxotag</Card>
    
    <Card name="raja"> Welcome to Maxotag </Card>
    <Card name="sham"> Welcome to Maxotag </Card>
    <Card name="kachru"> Welcome to Maxotag </Card>
    <Card name="lakhan"> Welcome to Maxotag </Card>
    <Card name="ravsaheb"> Welcome to Maxotag </Card>
    
    
    
    </>
    
  )
}

export default App;